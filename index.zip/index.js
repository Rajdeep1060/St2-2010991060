function check(){
	var fname=document.getElementById("fname").value;
var lname=document.getElementById("lname").value;
var day=document.getElementById("day").value;
var month=document.getElementById("month").value;
var year=document.getElementById("year").value;
var email=document.getElementById("email").value;
var mobile=document.getElementById("mobile").value;
var gender;
if(document.getElementById('m').checked) {
   gender = document.getElementById('m').value;
  }
  else{
  gender=document.getElementById('f').value;
  }
var hobbies;
if(document.getElementById("draw").checked){
	hobbies="drawing"+" ";
}
if(document.getElementById("sing").checked){
	hobbies="singing"+" ";
}
if(document.getElementById("dance").checked){
	hobbies="dancing"+" ";
}
if(document.getElementById("sketch").checked){
	hobbies="sketching"+" ";
}
if(document.getElementById("others").checked){
	hobbies=document.getElementById("othersfield")
}
var city=document.getElementById("city").value;
var pin=document.getElementById("pin").value;
var state=document.getElementById("state").value;
var country=document.getElementById("country").value;
var xboard=document.getElementById("xboard").value;
var xper=document.getElementById("xper").value;
var xyop=document.getElementById("xyop").value;
var xiiboard=document.getElementById("xiiboard").value;
var xiiper=document.getElementById("xiiper").value;
var xiiyop=document.getElementById("xiiyop").value;
var grad=document.getElementById("grad").value;
var gradper=document.getElementById("gradper").value;
var gradyop=document.getElementById("gradyop").value;
var master=document.getElementById("master").value;
var masterper=document.getElementById("masterper").value;
var masteryop=document.getElementById("masteryop").value;
var course;
xper=parseFloat(xper).toFixed(2);
xiiper=parseFloat(xiiper).toFixed(2);
gradper=parseFloat(gradper).toFixed(2);
masterper=parseFloat(masterper).toFixed(2);
if(document.getElementById('bca').checked) {
   course ="bca";
  }
  else if(document.getElementById('bcom').checked){
  course="bcom";
  }
  else if(document.getElementById('bsc').checked){
	course="bsc";
	}
	else{
		course="ba";
	}
	let n=true;
	let m=true;
	let p=true;
	if(fname.length==0 || lname.length==0){
		alert("Invalid length of name"); 
		n=false;
	}
	if(mobile.length==0 || mobile.length>10){
		alert("Invalid length of mobile"); 
		m=false;
	}
	if(pin.length==0 || pin.length>6){
		alert("Pin invalid");
		p=false;
	}
	
	var c=prompt("Do you want to cotinue yes or No");
	if((c=="yes"||c=="YES") && n && m && p ){
		alert("OK");
		console.log(fname);
		console.log(lname);
		console.log(day);
		console.log(month);
		console.log(year);
		console.log(mobile);
		console.log(gender);
		console.log(city);
		console.log(state);
		console.log(pin);
		console.log(country);
		console.log(xboard);
		console.log(xper);
		console.log(xyop);
		console.log(xiiboard);
		console.log(xiiper);
		console.log(xiiyop);
		console.log(grad);
		console.log(gradper);
		console.log(gradyop);
		console.log(master);
		console.log(masterper);
		console.log(masteryop);
		console.log(course);
		document.getElementById("form").style.display="none";
		document.body.style.backgroundColor="Black";
		document.body.style.color="White";
		document.getElementById("display").innerHTML="First Name:-"+ fname+"<br>";
		document.getElementById("display1").innerHTML="Last Name:- " + lname +"<br>";
		document.getElementById("display2").innerHTML="Date:- 30-9-2002"+"<br>";
		document.getElementById("display4").innerHTML="mobile :- " +mobile +"\n";
		document.getElementById("display5").innerHTML="gender:- "+gender +"\n";
		document.getElementById("display6").innerHTML="city:- "+city +"\n";
		document.getElementById("display7").innerHTML="state:- "+state +"\n";
		document.getElementById("display8").innerHTML="pin:- "+pin +"\n";
		document.getElementById("display9").innerHTML="country:- "+country +"\n";
		document.getElementById("display9").innerHTML="hobbies:- "+hobbies +"\n";
		document.getElementById("display10").innerHTML=" X board:- "+xboard +"\n";
		document.getElementById("display11").innerHTML=" X per:- "+xper +"\n";
		document.getElementById("display12").innerHTML=" X yr:- "+xyop +"\n";
		document.getElementById("display13").innerHTML=" XII board:- "+xiiboard +"\n";
		document.getElementById("display14").innerHTML=" XII per:- "+xiiper +"\n";
		document.getElementById("display15").innerHTML=" XII yr:- "+xiiyop +"\n";
		document.getElementById("display16").innerHTML=" grad :- "+grad +"\n";
		document.getElementById("display17").innerHTML=" grad per :- "+gradper +"\n";
		document.getElementById("display18").innerHTML=" grad yr :- "+gradyop +"\n";
		document.getElementById("display19").innerHTML=" master :- "+master +"\n";
		document.getElementById("display20").innerHTML=" master per :- "+masterper +"\n";
		document.getElementById("display21").innerHTML=" master yr :- "+masteryop +"\n";
	}


	}

